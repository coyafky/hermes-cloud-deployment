# 有膜有漾 Hermes Profile Upload Package

This package is intended to be copied into the server user's `~/.hermes/` directory.

Expected destination:

```text
~/.hermes/profiles/ymyy-sales-agent/
~/.hermes/skills/ask-with-mom-test/
~/.hermes/skills/diagnose-with-spin-selling/
~/.hermes/skills/answer-customer-faq-transparently/
~/.hermes/skills/negotiate-with-tactical-empathy/
~/.hermes/skills/strengthen-sales-wording-with-influence/
~/.hermes/skills/recommend-film-product/
~/.hermes/skills/handle-film-objections/
~/.hermes/skills/write-sales-followup/
~/.hermes/knowledge-base/ymyy-sales-agent/
```

After upload, point the Feishu/Hermes gateway to profile `ymyy-sales-agent`.
